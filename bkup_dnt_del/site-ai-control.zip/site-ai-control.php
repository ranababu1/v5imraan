<?php
/**
 * Plugin Name: Site AI Control
 * Description: Controlled WordPress Abilities for MCP/AI agents, focused on SEO, content, find-and-replace, post dates, AI-slop detection, and Google Site Kit data.
 * Version: 0.4.0
 * Author: Imran
 * Requires at least: 6.9
 * Requires PHP: 7.4
 * License: GPL-2.0-or-later
 * Text Domain: site-ai-control
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Extend the maintained MCP OAuth trusted-publisher list with Grok's
 * published Client ID Metadata Document (CIMD) identity.
 *
 * The wp-media/mcp-oauth library keeps an explicit trusted-publisher
 * allowlist. This does not open OAuth to arbitrary clients. The library
 * continues to validate the publisher metadata and trusted host.
 */
/**
 * Add known MCP publishers and allow standards-compliant CIMD clients.
 *
 * The current wp-media/mcp-oauth release treats trusted publishers as a
 * trust signal by default. Older releases used the allowlist as a hard gate.
 * We explicitly enable untrusted providers so other legitimate MCP clients
 * can complete OAuth; the OAuth library still validates the CIMD URL, HTTPS,
 * redirect URIs, PKCE, and WordPress consent.
 */
add_filter(
	'wpmedia_mcp_oauth_allow_untrusted_providers',
	'__return_true',
	10
);

add_filter(
	'wpmedia_mcp_oauth_trusted_publishers',
	static function ( array $publishers ): array {
		$publishers['grok'] = array(
			'client_ids' => array(
				'https://grok.com/oauth/mcp-client.json',
			),
			'host'       => 'grok.com',
		);

		return $publishers;
	},
	10
);

define( 'SITE_AI_CONTROL_VERSION', '0.4.0' );
define( 'SITE_AI_CONTROL_FILE', __FILE__ );
define( 'SITE_AI_CONTROL_DIR', plugin_dir_path( __FILE__ ) );

require_once SITE_AI_CONTROL_DIR . 'includes/class-site-ai-control.php';
require_once SITE_AI_CONTROL_DIR . 'includes/class-site-ai-abilities.php';
require_once SITE_AI_CONTROL_DIR . 'includes/class-site-ai-seo.php';
require_once SITE_AI_CONTROL_DIR . 'includes/class-site-ai-content.php';
require_once SITE_AI_CONTROL_DIR . 'includes/class-site-ai-google.php';
require_once SITE_AI_CONTROL_DIR . 'includes/class-site-ai-health.php';
require_once SITE_AI_CONTROL_DIR . 'includes/class-site-ai-slop.php';

add_action(
	'plugins_loaded',
	static function () {
		\Site_AI_Control\Plugin::init();
	}
);
